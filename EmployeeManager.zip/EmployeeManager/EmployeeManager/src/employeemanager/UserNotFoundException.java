package employeemanager;

/**
 *
 * @author Raafee-M
 */

public class UserNotFoundException extends Exception {
    public UserNotFoundException(String message) {
        super(message);
    }
}

