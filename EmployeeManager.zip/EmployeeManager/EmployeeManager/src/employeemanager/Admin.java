package employeemanager;

/**
 *
 * @author Raafee-M
 */

public class Admin extends User{
    
    public Admin() {
        super("admin", "admin432", true);
    }
    
    
    
}
