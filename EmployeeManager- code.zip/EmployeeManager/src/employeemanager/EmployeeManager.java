package employeemanager;

import GUI.SplashScreen;


public class EmployeeManager {


    public static void main(String[] args) {
        
        SplashScreen l1 = new SplashScreen();
        
        l1.setVisible(true);
    }
    
}
