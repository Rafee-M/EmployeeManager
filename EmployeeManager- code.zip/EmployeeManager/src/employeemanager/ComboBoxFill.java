package employeemanager;

/**
 *
 * @author Rafee-M
 */

public interface ComboBoxFill {
    public void fillComboBox();
}
